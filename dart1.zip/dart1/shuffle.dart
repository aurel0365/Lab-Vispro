List<int> shuffleList(List<int> angka) {
  angka.shuffle();
  return angka;
}
